<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Breaking Bad XSS Challenge</title>
  <style>
    body {
      background-color: #0d0d0d;
      color: #0f0;
      font-family: monospace;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    input {
      background-color: #111;
      color: #0f0;
      border: 1px solid #0f0;
      padding: 10px;
      font-size: 18px;
      width: 400px;
      margin-top: 10px;
    }
    #hint {
      margin-bottom: 30px;
      font-size: 18px;
      max-width: 600px;
      text-align: center;
    }
  </style>
  <script>
    // Override alert before any user script runs
    (function() {
      let firstAlertTriggered = false;
      const originalAlert = window.alert;
      window.alert = function(message) {
        originalAlert(message);
        if (!firstAlertTriggered) {
          firstAlertTriggered = true;
          setTimeout(() => {
            originalAlert("//");
          }, 300);
        }
      };
    })();
  </script>
</head>
<body>
  <div id="hint">
    "You're not just in danger, Skyler. I am the danger."<br />
    The chemistry starts with a *reaction*... 🧪
  </div>

  <form method="GET">
    <input
      type="text"
      name="payload"
      placeholder="What would Heisenberg do?"
      autocomplete="off"
      autofocus
    />
  </form>

  <div id="output">
    <?php
      if (isset($_GET['payload'])) {
        // Output raw user payload (XSS vector)
        echo $_GET['payload'];
      }
    ?>
  </div>
</body>
</html>
