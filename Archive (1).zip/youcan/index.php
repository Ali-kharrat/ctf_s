<?php
$mysqli = new mysqli("localhost", "ctfuser", "yourpassword", "breakingbadctf");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$input = isset($_GET['input']) ? $_GET['input'] : '';
$error = '';
$results = [];

if ($input !== '') {
    // کوئری آسیب‌پذیر
    $query = "SELECT * FROM users WHERE username = '$input'";

    $res = $mysqli->query($query);

    if (!$res) {
        $error = "SQL Error: " . $mysqli->error;
    } else {
        while ($row = $res->fetch_assoc()) {
            $results[] = $row;
        }
        $res->free();
    }
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Breaking Bad CTF - SQL Injection</title>
<style>
    body {
        background-color: #000;
        color: #0f0;
        font-family: 'Courier New', Courier, monospace;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding-top: 50px;
    }
    input, button {
        padding: 10px;
        font-size: 1rem;
        background: #111;
        color: #0f0;
        border: 1px solid #0f0;
        margin: 10px 0;
    }
    .container {
        width: 400px;
        border: 2px solid #0f0;
        padding: 20px;
        border-radius: 10px;
        box-sizing: border-box;
    }
    .hint {
        font-size: 0.85rem;
        color: #666;
        margin-top: 15px;
        border-top: 1px solid #0f0;
        padding-top: 10px;
    }
    .error {
        color: #f00;
        margin-top: 10px;
    }
    .result {
        background: #002200;
        margin-top: 20px;
        padding: 15px;
        border-radius: 8px;
        white-space: pre-wrap;
    }
</style>
</head>
<body>
<div class="container">
    <h2>Enter username</h2>
    <form method="GET">
        <input type="text" name="input" autocomplete="off" value="<?=htmlspecialchars($input)?>" placeholder="Try to find the flag..." />
        <br />
        <button type="submit">Search</button>
    </form>

    <?php if ($error): ?>
        <div class="error"><?=htmlspecialchars($error)?></div>
    <?php endif; ?>

    <?php if (count($results) > 0): ?>
        <div class="result">
            <?php foreach($results as $row): ?>
                Username: <?=htmlspecialchars($row['username'])?>
                Flag: <?=htmlspecialchars($row['flag'])?><br /><br />
            <?php endforeach; ?>
        </div>
    <?php elseif ($input !== ''): ?>
        <div class="result">No results found.</div>
    <?php endif; ?>

    <div class="hint">
        Hint: "Just like Heisenberg manipulated chemistry, try to manipulate the query.<br />
    </div>
</div>
</body>
</html>
