
console.log("Proceed to: /heisenberg/");
// FLAG{looking-crefully}
