<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "Next stop: /saul-goodman/";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <style>
        body {
            background-color: #000;
            color: #39ff14;
            font-family: 'Courier New', monospace;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .hint-box {
            text-align: center;
            border: 2px solid #39ff14;
            padding: 20px;
            border-radius: 10px;
        }
        .hint {
            font-size: 1.4rem;
        }
    </style>
</head>
<body>
    <div class="hint-box">
        <p class="hint">"Words won't help. Try action. POST somtings for me..."</p>
    </div>
</body>
</html>

