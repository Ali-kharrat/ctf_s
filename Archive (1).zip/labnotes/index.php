<?php
setcookie("next_path", "/lab/", time() + 3600); // کوکی یک ساعته
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title></title>
  <style>
    body {
      background-color: black;
      color: #39FF14;
      font-family: 'Courier New', Courier, monospace;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      flex-direction: column;
    }

    .dialog {
      border: 2px solid #39FF14;
      padding: 30px;
      font-size: 20px;
      max-width: 600px;
      text-align: center;
    }

    .greet {
      margin-top: 20px;
      font-size: 14px;
      color: #39FF14;
    }
  </style>
</head>
<body>
  <div class="dialog">
    "You don’t know what you don’t know…"
  </div>
</body>
</html>

