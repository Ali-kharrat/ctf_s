<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Level 4</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="hint-box">
            <p class="hint">"Style reveals more than you think."</p>
        </div>
    </div>
</body>
</html>

