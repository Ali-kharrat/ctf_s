<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title></title>
  <style>
    body {
      background-color: black;
      color: #39FF14; /* neon green */
      font-family: 'Courier New', monospace;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      flex-direction: column;
    }
    .dialogue-box {
      border: 2px solid #39FF14;
      padding: 20px;
      max-width: 600px;
      text-align: center;
    }
    .hello {
      margin-top: 20px;
      color: white;
    }
  </style>
</head>
<body>
  <div class="dialogue-box">
    "U2F5IG15IG5hbWUsIHlvdSBjYW4gZmluZCB0aGUgbmV4dCBsZXZlbCBhdCAvd2FsdGVyLw=="
  </div>
</body>
</html>

